<?php
	cherry_static_area( 'header-top' );
	cherry_static_area( 'header-bottom' );
	cherry_static_area( 'showcase-area' );
?>